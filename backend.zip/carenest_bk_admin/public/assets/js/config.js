// all the urls 

var apiConfig = {
    hub: 'http://localhost:7000/api/hub',
    hur: 'http://localhost:7000/api/hr'
}



