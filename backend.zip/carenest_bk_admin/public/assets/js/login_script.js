function getCookie(name) {
    // Construct the pattern to search for the cookie
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);

    // If the cookie is found, return its value
    if (parts.length === 2) {
        return parts.pop().split(';').shift();
    }

    // Return null if the cookie doesn't exist
    return null;
}

function generateMessage(msg, type) {

    const flashMsg = `<div class="alert ${type} alert-dismissible fade show" role="alert">
                    ${msg}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>`;

    $('.flash-messages').empty().append(flashMsg);
    return;
}

function generateMultipleMessages(messageArray, type) {

    const flashMsg = messageArray.map((msg) => {
        return `<div class="alert ${type} alert-dismissible fade show" role="alert">
                    ${msg}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>`
    });

    $('.flash-messages').empty().append(flashMsg);
    return;
}

$(document).ready(function () {

    $('.loginForm').submit(function (e) {
        e.preventDefault();

        const redirectURICookie = getCookie('redirect_uri');

        var url = $(this).attr('action');
        $('#preloader').show();

        $.ajax({
            type: "POST",
            url: url,
            data: new FormData(this),
            dataType: 'json',
            processData: false,
            contentType: false,
        })
            .done(function (data) {
                $('#preloader').hide();
                var response = $.parseJSON(data.response)
                if (data.response_code == 200) {

                    $('#login-button').hide();
                    // if message
                    if (response.message != '') {
                        generateMessage(response.message, 'alert-success');
                    }

                    // if redirect cookie
                    if (redirectURICookie != '' && redirectURICookie != undefined) {
                        setTimeout(() => {
                            location.href = viewConfig[redirectURICookie];
                        }, 2000);
                    } else {
                        // if redirect url
                        var redirect_url = (viewConfig[response.redirect_url] !== undefined) ? viewConfig[response.redirect_url] : response.redirect_url;

                        setTimeout(() => {
                            location.href = redirect_url;
                        }, 2000);

                    }

                } else {
                    // if validation errors
                    if (response.validation_errors && response.validation_errors != '') {
                        generateMultipleMessages(response.validation_errors, 'alert-danger');
                    }

                    // if message
                    if (response.message && response.message != '') {
                        generateMessage(response.message, 'alert-danger');
                    }

                    if (response.reload && response.reload !== 'NO') {
                        setTimeout(() => {
                            location.reload();
                        }, 2000);
                    }
                }
            });
    });
});