function getCookie(name) {
    // Construct the pattern to search for the cookie
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);

    // If the cookie is found, return its value
    if (parts.length === 2) {
        return parts.pop().split(';').shift();
    }

    // Return null if the cookie doesn't exist
    return null;
}

function deleteCookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;'; // Adjust the domain if necessary
}

// utility functions
function hidePreloader() {
    setTimeout(() => {
        $('#preloader').hide();
    }, 2000);
}

function showPreloader() {
    $('#preloader').show();
}

// utility functions

$(document).ready(function () {


    const jwtToken = getCookie('JWT-TOKEN');

    $('[id^=generic_form]').submit(function (e) {

        e.preventDefault();
        showPreloader();
        var url = $(this).attr('action');

        $.ajax({
            type: "POST",
            url: url,
            data: new FormData(this),
            dataType: 'json',
            processData: false,
            contentType: false,
            headers: {
                'Authorization': `Bearer ${jwtToken}` // Include the JWT in the Authorization header
            },
            xhrFields: {
                withCredentials: true
            },
        })
            .done(function (data) {
                console.log(data);
                var response = $.parseJSON(data.response)
                if (data.response_code == 200) {


                    // if message
                    console.log(response.message);

                    // if redirect url
                    if (response.redirect_url && response.redirect_url != '') {
                        var redirect_url = (viewConfig[response.redirect_url] !== undefined) ? viewConfig[response.redirect_url] : response.redirect_url;

                        setTimeout(() => {
                            location.href = redirect_url;
                        }, 2000);
                    }

                    // if data

                } else {
                    // if validation errors
                    console.log(response.validation_errors);

                    // if message
                    console.log(response.message);

                    if (response.reload !== 'NO') {
                        setTimeout(() => {
                            location.reload();
                        }, 2000);
                    }
                }
            });
    });

    $('#logout').click(function (e) {
        e.preventDefault();
        showPreloader();
        deleteCookie('redirect_uri');
        deleteCookie('JWT-TOKEN');


        setTimeout(() => {
            location.reload();
        }, 2000);

    });


});