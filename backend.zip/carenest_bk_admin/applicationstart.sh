#!/bin/bash

cd /var/www/html/codedeploy/
service apache2 restart