#!/bin/bash

cd /var/www/html/codedeploy/
chown -R www-data:www-data writable/
sudo systemctl restart apache2
chmod 777 writable
chmod 777 writable/cache