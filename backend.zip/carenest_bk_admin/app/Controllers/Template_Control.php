<?php

namespace App\Controllers;

// ALL CONTROLLERS MUST FOLLOW THIS FORMAT

class Template_Control extends Default_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->session = \Config\Services::session();
        $this->uri = new \CodeIgniter\HTTP\URI();
    }

    public function index(){

        $message= $this->message_object('You have reached carenest admin backend');
        return $this->success_message_array($message);
    }   
}