<?php

namespace App\Controllers;

class Default_Controller extends BaseController
{
    protected $helpers = [];
    protected $libraries = [];

    public function __construct()
    {
        helper(['url', 'form', 'session']);
        $this->session = \Config\Services::session();

        set_time_limit(0);
        ini_set('memory_limit', '2G');

    }

    public function message_object($message = null, $validation_errors = null, $data = null, $redirect_url = null, $reload = 'NO')
    {
        $validation_errors_array = [];
        if (!empty($validation_errors)) {
            foreach ($validation_errors as $err) {
                $validation_errors_array[] = $err;
            }
        }
        return json_encode(
            array(
                'message' => $message,
                'redirect_url' => $redirect_url,
                'data' => $data,
                'validation_errors' => $validation_errors_array,
                'reload' => $reload
            )
        );
    }
    
    public function unauthorized_message()
    {
        return $this->response->setJSON([ 'response_code' => 500, 'response' =>  ["message"=>"This request origin is not registered and cannot be authorized!"]]);
    }

    public function success_message_array($message = array())
    {
        return $this->response->setJSON([ 'response_code' => 200, 'response' => $message]);
    }

    public function failed_message_array($message = array())
    {
        return $this->response->setJSON([ 'response_code' => 500, 'response' => $message]);
    }

}